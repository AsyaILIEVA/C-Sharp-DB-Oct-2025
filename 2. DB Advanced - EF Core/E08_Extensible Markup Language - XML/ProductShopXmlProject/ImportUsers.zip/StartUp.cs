﻿namespace ProductShop
{
    using System.ComponentModel.DataAnnotations;
    using System.Text;

    using Data;
    //using DTOs.Export;
    using DTOs.Import;
    using Models;
    using Utilities;

    using Microsoft.EntityFrameworkCore;

    public class StartUp
    {
        public static void Main()
        {
            using ProductShopContext dbContext = new ProductShopContext();

            //dbContext.Database.EnsureDeleted();
            //dbContext.Database.EnsureCreated();

            string xmlFileText = ReadXmlDatasetFileContents("users.xml");
            string result = ImportUsers(dbContext, xmlFileText);

            Console.WriteLine(result);
        }

        // Problem 01
        public static string ImportUsers(ProductShopContext context, string inputXml)
        {
            ICollection<User> usersToImport = new List<User>();

            ImportUserDto[]? importUserDtos = XmlSerializerWrapper
                .Deserialize<ImportUserDto[]>(inputXml, "Users");
            if (importUserDtos != null)
            {
                foreach (ImportUserDto userDto in importUserDtos)
                {
                    if (!IsValid(userDto))
                    {
                        continue;
                    }

                    bool isAgeValid =
                        TryParseNullableInt(userDto.Age, out int? age);
                    if (!isAgeValid)
                    {
                        continue;
                    }

                    User newUser = new User()
                    {
                        FirstName = userDto.FirstName,
                        LastName = userDto.LastName,
                        Age = age
                    };
                    usersToImport.Add(newUser);
                }

                context.Users.AddRange(usersToImport);
                context.SaveChanges();
            }

            return $"Successfully imported {usersToImport.Count}";
        }

        private static string ReadXmlDatasetFileContents(string fileName)
        {
            string xmlFileDirPath = Path
                .Combine(Directory.GetCurrentDirectory(), "../../../Datasets/");
            string xmlFileText = File
                .ReadAllText(xmlFileDirPath + fileName);

            return xmlFileText;
        }

        private static bool TryParseNullableInt(string? input, out int? val)
        {            
            int? outValue = null;
            if (input != null)
            {
                bool isInputValid = int
                    .TryParse(input, out int ageVal);
                if (!isInputValid)
                {
                    val = outValue;
                    return false;
                }

                outValue = ageVal;
            }

            val = outValue;
            return true;
        }

        private static bool IsValid(object obj)
        {
            ValidationContext validationContext = new ValidationContext(obj);
            ICollection<ValidationResult> validationResults
                = new List<ValidationResult>();

            return Validator
                .TryValidateObject(obj, validationContext, validationResults);
        }

    }
    
}