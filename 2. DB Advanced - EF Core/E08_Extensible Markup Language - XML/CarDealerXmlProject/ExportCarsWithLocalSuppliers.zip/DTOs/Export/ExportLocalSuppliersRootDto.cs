﻿using System.Xml.Serialization;

[XmlType("suppliers")]
public class ExportLocalSuppliersRootDto
{
    [XmlElement("supplier")]
    public ExportLocalSupplierDto[] Suppliers { get; set; } = null!;
}
