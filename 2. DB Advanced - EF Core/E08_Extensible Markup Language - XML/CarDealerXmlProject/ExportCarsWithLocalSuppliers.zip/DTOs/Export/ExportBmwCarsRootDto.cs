﻿using System.Xml.Serialization;

[XmlType("cars")]
public class ExportBmwCarsRootDto
{
    [XmlElement("car")]
    public ExportBmwCarDto[] Cars { get; set; } = null!;
}
