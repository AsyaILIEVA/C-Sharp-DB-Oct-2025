﻿using CarDealer.Data;
using CarDealer.DTOs.Import;
using CarDealer.Models;
using CarDealer.Utilities;
using System.ComponentModel.DataAnnotations;
using System.Xml.Serialization;

namespace CarDealer
{
    public class StartUp
    {
        public static void Main()
        {
            using CarDealerContext dbContext = new CarDealerContext();
            //dbContext.Database.EnsureDeleted();
            //dbContext.Database.EnsureCreated();

            //string xmlFileText = ReadXmlDatasetFileContents("suppliers.xml");
            //string result = ImportSuppliers(dbContext, xmlFileText);

            string xmlFileText = ReadXmlDatasetFileContents("parts.xml");
            string result = ImportParts(dbContext, xmlFileText);

            Console.WriteLine(result);            
        }

        // Problem 09
        public static string ImportSuppliers(CarDealerContext context, string inputXml)
        {
            ICollection<Supplier> suppliersToImport = new List<Supplier>();

            ImportSupplierDto[]? importSupplierDtos = XmlSerializerWrapper
                .Deserialize<ImportSupplierDto[]>(inputXml, "Suppliers");
            if (importSupplierDtos != null)
            {
                foreach (ImportSupplierDto supplierDto in importSupplierDtos)
                {
                    if (!IsValid(supplierDto))
                    {
                        continue;
                    }
                    
                    Supplier newSupplier = new Supplier()
                    {
                        Name = supplierDto.Name,
                        IsImporter = supplierDto.IsImporter,
                        
                    };
                    suppliersToImport.Add(newSupplier);
                }

                context.Suppliers.AddRange(suppliersToImport);
                context.SaveChanges();
            }

            return $"Successfully imported {suppliersToImport.Count}";
        }

        ////P10
        //public static string ImportParts(CarDealerContext context, string inputXml)
        //{
        //    ICollection<Part> partsToImport = new List<Part>();

        //    ImportPartDto[]? importPartDtos = XmlSerializerWrapper
        //        .Deserialize<ImportPartDto[]>(inputXml, "Parts");
        //    if (importPartDtos != null)
        //    {
        //        foreach (ImportPartDto partDto in importPartDtos)
        //        {
        //            if (!IsValid(partDto))
        //            {
        //                continue;
        //            }

        //            //bool isSupplierIdNotValid = string.IsNullOrEmpty(partDto.SupplierId);
        //            //if (isSupplierIdNotValid)
        //            //{
        //            //    continue;
        //            //}


        //            //string? -> int?
        //            //bool isSupplierIdValid =
        //            //    TryParseNullableInt(partDto.SupplierId, out int? supplierIdVal);

        //            //bool isPriceValid = decimal
        //            //    .TryParse(partDto.Price, out decimal priceVal);
        //            //bool isQuantitydValid = int
        //            //    .TryParse(partDto.Quantity, out int quantityVal);

        //            ////string? -> int
        //            //bool isSupplierIdValid = int
        //            //    .TryParse(partDto.SupplierId, out int supplierIdVal);
        //            //if (!isPriceValid || !isQuantitydValid || !isSupplierIdValid)
        //            //{
        //            //    continue;
        //            //}
        //            bool supplierExists = context
        //                .Suppliers.Any(s => s.Id == partDto.SupplierId);
        //            if (!supplierExists)
        //            {
        //                continue;
        //            }

        //            Part newPart = new Part()
        //            {
        //                Name = partDto.Name,
        //                Price = partDto.Price,
        //                Quantity = partDto.Quantity,
        //                SupplierId = partDto.SupplierId, 
        //            };
        //            partsToImport.Add(newPart);
        //        }

        //        context.Parts.AddRange(partsToImport);
        //        context.SaveChanges();
        //    }

        //    return $"Successfully imported {partsToImport.Count}";
        //}

        private static string ReadXmlDatasetFileContents(string fileName)
        {
            string xmlFileDirPath = Path
                .Combine(Directory.GetCurrentDirectory(), "../../../Datasets/");
            string xmlFileText = File
                .ReadAllText(xmlFileDirPath + fileName);

            return xmlFileText;
        }

        
    public static string ImportParts(CarDealerContext context, string inputXml)
        {
            XmlSerializer xmlSerializer =
                new XmlSerializer(typeof(ImportPartDto[]), new XmlRootAttribute("Parts"));

            using StringReader reader = new StringReader(inputXml);

            var partDtos = (ImportPartDto[])xmlSerializer.Deserialize(reader);

            var validSupplierIds = context.Suppliers
                .Select(s => s.Id)
                .ToHashSet();

            List<Part> parts = new List<Part>();

            foreach (var dto in partDtos)
            {
                if (!validSupplierIds.Contains(dto.SupplierId))
                    continue;

                Part part = new Part
                {
                    Name = dto.Name,
                    Price = dto.Price,
                    Quantity = dto.Quantity,
                    SupplierId = dto.SupplierId
                };

                parts.Add(part);
            }

            context.Parts.AddRange(parts);
            context.SaveChanges();

            return $"Successfully imported {parts.Count}";
        }
    


        private static bool TryParseNullableInt(string? input, out int? val)
        {
            int? outValue = null;
            if (input != null)
            {
                bool isInputValid = int
                    .TryParse(input, out int ageVal);
                if (!isInputValid)
                {
                    val = outValue;
                    return false;
                }

                outValue = ageVal;
            }

            val = outValue;
            return true;
        }

        private static bool IsValid(object obj)
        {
            ValidationContext validationContext = new ValidationContext(obj);
            ICollection<ValidationResult> validationResults
                = new List<ValidationResult>();

            return Validator
                .TryValidateObject(obj, validationContext, validationResults);
        }
    }
}

