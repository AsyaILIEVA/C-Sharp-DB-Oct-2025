﻿using System.ComponentModel.DataAnnotations;
using System.Xml.Serialization;

namespace CarDealer.DTOs.Import
{
    [XmlType("Sale")]
    public class ImportSaleDto
    {
        [Required]
        [XmlElement("carId")]
        public int CarId { get; set; } 

        [Required]
        [XmlElement("customerId")]
        public int CustomerId { get; set; } 

        [Required]
        [XmlElement("discount")]
        public decimal Discount { get; set; } 
    }
}
