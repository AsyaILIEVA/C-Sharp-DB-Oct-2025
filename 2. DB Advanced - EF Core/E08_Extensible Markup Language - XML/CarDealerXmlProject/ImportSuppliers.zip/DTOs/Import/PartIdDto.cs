﻿
using System.Xml.Serialization;

namespace CarDealer.DTOs.Import
{
    public class PartIdDto
    {
        [XmlAttribute("id")]
        public string Id { get; set; } = null!;
    }
}
