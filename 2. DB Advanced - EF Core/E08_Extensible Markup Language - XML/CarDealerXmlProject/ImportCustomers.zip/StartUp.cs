﻿using CarDealer.Data;
using CarDealer.DTOs.Import;
using CarDealer.Models;
using CarDealer.Utilities;
using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Xml.Serialization;

namespace CarDealer
{
    public class StartUp
    {
        public static void Main()
        {
            using CarDealerContext dbContext = new CarDealerContext();
            //dbContext.Database.EnsureDeleted();
            //dbContext.Database.EnsureCreated();

            //string xmlFileText = ReadXmlDatasetFileContents("suppliers.xml");
            //string result = ImportSuppliers(dbContext, xmlFileText);

            //string xmlFileText = ReadXmlDatasetFileContents("parts.xml");
            //string result = ImportParts(dbContext, xmlFileText);

            //string xmlFileText = ReadXmlDatasetFileContents("cars.xml");
            //string result = ImportCars(dbContext, xmlFileText);

            string xmlFileText = ReadXmlDatasetFileContents("customers.xml");
            string result = ImportCustomers(dbContext, xmlFileText);

            Console.WriteLine(result);

            //Console.WriteLine("Suppliers count: " + dbContext.Suppliers.Count());
            //Console.WriteLine("Parts count: " + dbContext.Parts.Count());

        }

        // Problem 09
        public static string ImportSuppliers(CarDealerContext context, string inputXml)
        {
            ICollection<Supplier> suppliersToImport = new List<Supplier>();

            ImportSupplierDto[]? importSupplierDtos = XmlSerializerWrapper
                .Deserialize<ImportSupplierDto[]>(inputXml, "Suppliers");
            if (importSupplierDtos != null)
            {
                foreach (ImportSupplierDto supplierDto in importSupplierDtos)
                {
                    if (!IsValid(supplierDto))
                    {
                        continue;
                    }
                    
                    Supplier newSupplier = new Supplier()
                    {
                        Name = supplierDto.Name,
                        IsImporter = supplierDto.IsImporter,
                        
                    };
                    suppliersToImport.Add(newSupplier);
                }

                context.Suppliers.AddRange(suppliersToImport);
                context.SaveChanges();
            }

            return $"Successfully imported {suppliersToImport.Count}";
        }

        ////P10
        //public static string ImportParts(CarDealerContext context, string inputXml)
        //{
        //    ICollection<Part> partsToImport = new List<Part>();

        //    ImportPartDto[]? importPartDtos = XmlSerializerWrapper
        //        .Deserialize<ImportPartDto[]>(inputXml, "Parts");
        //    if (importPartDtos != null)
        //    {
        //        foreach (ImportPartDto partDto in importPartDtos)
        //        {
        //            if (!IsValid(partDto))
        //            {
        //                continue;
        //            }

        //            //bool isSupplierIdNotValid = string.IsNullOrEmpty(partDto.SupplierId);
        //            //if (isSupplierIdNotValid)
        //            //{
        //            //    continue;
        //            //}


        //            //string? -> int?
        //            //bool isSupplierIdValid =
        //            //    TryParseNullableInt(partDto.SupplierId, out int? supplierIdVal);

        //            //bool isPriceValid = decimal
        //            //    .TryParse(partDto.Price, out decimal priceVal);
        //            //bool isQuantitydValid = int
        //            //    .TryParse(partDto.Quantity, out int quantityVal);

        //            ////string? -> int
        //            //bool isSupplierIdValid = int
        //            //    .TryParse(partDto.SupplierId, out int supplierIdVal);
        //            //if (!isPriceValid || !isQuantitydValid || !isSupplierIdValid)
        //            //{
        //            //    continue;
        //            //}
        //            bool supplierExists = context
        //                .Suppliers.Any(s => s.Id == partDto.SupplierId);
        //            if (!supplierExists)
        //            {
        //                continue;
        //            }

        //            Part newPart = new Part()
        //            {
        //                Name = partDto.Name,
        //                Price = partDto.Price,
        //                Quantity = partDto.Quantity,
        //                SupplierId = partDto.SupplierId, 
        //            };
        //            partsToImport.Add(newPart);
        //        }

        //        context.Parts.AddRange(partsToImport);
        //        context.SaveChanges();
        //    }

        //    return $"Successfully imported {partsToImport.Count}";
        //}

        private static string ReadXmlDatasetFileContents(string fileName)
        {
            string xmlFileDirPath = Path
                .Combine(Directory.GetCurrentDirectory(), "../../../Datasets/");
            string xmlFileText = File
                .ReadAllText(xmlFileDirPath + fileName);

            return xmlFileText;
        }

        
    public static string ImportParts(CarDealerContext context, string inputXml)
        {
            XmlSerializer xmlSerializer =
                new XmlSerializer(typeof(ImportPartDto[]), new XmlRootAttribute("Parts"));

            using StringReader reader = new StringReader(inputXml);

            var partDtos = (ImportPartDto[])xmlSerializer.Deserialize(reader);

            var validSupplierIds = context.Suppliers
                .Select(s => s.Id)
                .ToHashSet();

            List<Part> parts = new List<Part>();

            foreach (var dto in partDtos)
            {
                if (!validSupplierIds.Contains(dto.SupplierId))
                    continue;

                Part part = new Part
                {
                    Name = dto.Name,
                    Price = dto.Price,
                    Quantity = dto.Quantity,
                    SupplierId = dto.SupplierId
                };

                parts.Add(part);
            }

            context.Parts.AddRange(parts);
            context.SaveChanges();

            return $"Successfully imported {parts.Count}";
        }

        //public static string ImportCars(CarDealerContext context, string inputXml)
        //{
        //    ICollection<Car> carsToImport = new List<Car>();
        //    ICollection<PartCar> partsCarsToImport = new List<PartCar>();

        //    ImportCarDto[]? carDtos = XmlSerializerWrapper
        //    .Deserialize<ImportCarDto[]>(inputXml, "Cars");
        //    if (carDtos != null)
        //    {
        //        foreach (ImportCarDto carDto in carDtos)
        //        {
        //            if (!IsValid(carDto))
        //            {
        //                continue;
        //            }

        //            Car newCar = new Car()
        //            {
        //                Make = carDto.Make,
        //                Model = carDto.Model,
        //                TraveledDistance = carDto.TraveledDistance
        //            };
        //            carsToImport.Add(newCar);

        //            foreach (var partId in carDto.Parts.Distinct())
        //            {
        //                if (!context.Parts.Any(p => p.Id == partId))
        //                {
        //                    continue;
        //                }

        //                PartCar newPartCar = new PartCar()
        //                {
        //                    PartId = partId,
        //                    Car = newCar
        //                };
        //                partsCarsToImport.Add(newPartCar);
        //            }
        //        }                
        //        context.PartsCars.AddRange(partsCarsToImport);

        //        context.SaveChanges();
        //    }

        //    return $"Successfully imported {carsToImport.Count}.";
        //}

        //P10C
        public static string ImportCars(CarDealerContext context, string inputXml)
        {
            XmlRootAttribute root = new XmlRootAttribute("Cars");
            XmlSerializer serializer = new XmlSerializer(typeof(ImportCarDto[]), root);

            using StringReader reader = new StringReader(inputXml);
            ImportCarDto[] carDtos = (ImportCarDto[])serializer.Deserialize(reader);

            List<Car> cars = new List<Car>();

            var existingPartIds = context.Parts
                .Select(p => p.Id)
                .ToHashSet();

            foreach (var dto in carDtos)
            {
                var car = new Car
                {
                    Make = dto.Make,
                    Model = dto.Model,
                    TraveledDistance = dto.TraveledDistance
                };

                var uniqueValidPartIds = dto.Parts?
                    .Select(p => p.Id)
                    .Distinct()
                    .Where(id => existingPartIds.Contains(id))
                    .ToList()
                    ?? new List<int>();

                cars.Add(car);

                // INSERT PART-CAR RELATIONS EXPLICITLY THROUGH CONTEXT
                foreach (var partId in uniqueValidPartIds)
                {
                    context.PartsCars.Add(new PartCar
                    {
                        Car = car,
                        PartId = partId
                    });
                }
            }

            context.Cars.AddRange(cars);
            context.SaveChanges();

            return $"Successfully imported {cars.Count}";
        }

        public static string ImportCustomers(CarDealerContext context, string inputXml)
        {
            XmlRootAttribute root = new XmlRootAttribute("Customers");
            XmlSerializer serializer = new XmlSerializer(typeof(ImportCustomerDto[]), root);

            ImportCustomerDto[] customerDtos;

            using (StringReader reader = new StringReader(inputXml))
            {
                customerDtos = (ImportCustomerDto[])serializer.Deserialize(reader);
            }

            List<Customer> customers = new List<Customer>();

            foreach (var customerDto in customerDtos)
            {
                if (!IsValid(customerDto))
                {
                    continue;
                }

                bool isBirthDateValid = DateTime
                    .TryParseExact(customerDto.BirthDate, "yyyy-MM-dd'T'HH:mm:ss",
                        CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime birthDate);
                bool isYoungDriverValid = bool
                    .TryParse(customerDto.IsYoungDriver, out bool isYoungDriver);
                if ((!isBirthDateValid) || (!isYoungDriverValid))
                {
                    continue;
                }


                Customer cust = new Customer
                {
                    Name = customerDto.Name,
                    BirthDate = DateTime.Parse(customerDto.BirthDate),
                    IsYoungDriver = isYoungDriverValid
                };

                customers.Add(cust);
            }

            context.Customers.AddRange(customers);
            context.SaveChanges();

            return $"Successfully imported {customers.Count}";
        }


        //        ICollection<Product> productsToImport = new List<Product>();

        //        ImportProductDto[]? importProductDtos = XmlSerializerWrapper
        //            .Deserialize<ImportProductDto[]>(inputXml, "Products");
        //            if (importProductDtos != null)
        //            {
        //                foreach (ImportProductDto productDto in importProductDtos)
        //                {
        //                    if (!IsValid(productDto))
        //                    {
        //                        continue;
        //                    }

        //                    bool isPriceValid = decimal
        //                        .TryParse(productDto.Price, out decimal priceVal);
        //        bool isSellerIdValid = int
        //            .TryParse(productDto.SellerId, out int sellerIdVal);
        //        bool isBuyerIdValid =
        //            TryParseNullableInt(productDto.BuyerId, out int? buyerIdVal);
        //                    if (!isPriceValid || !isSellerIdValid || !isBuyerIdValid)
        //                    {
        //                        continue;
        //                    }

        //                    Product newProduct = new Product()
        //                    {
        //                        Name = productDto.Name,
        //                        Price = priceVal,
        //                        SellerId = sellerIdVal,
        //                        BuyerId = buyerIdVal
        //                    };
        //        productsToImport.Add(newProduct);
        //                }

        //    context.Products.AddRange(productsToImport);
        //                context.SaveChanges();
        //            }

        //return $"Successfully imported {productsToImport.Count}";
        //        }


        private static bool TryParseNullableInt(string? input, out int? val)
        {
            int? outValue = null;
            if (input != null)
            {
                bool isInputValid = int
                    .TryParse(input, out int ageVal);
                if (!isInputValid)
                {
                    val = outValue;
                    return false;
                }

                outValue = ageVal;
            }

            val = outValue;
            return true;
        }

        private static bool IsValid(object obj)
        {
            ValidationContext validationContext = new ValidationContext(obj);
            ICollection<ValidationResult> validationResults
                = new List<ValidationResult>();

            return Validator
                .TryValidateObject(obj, validationContext, validationResults);
        }
    }
}

