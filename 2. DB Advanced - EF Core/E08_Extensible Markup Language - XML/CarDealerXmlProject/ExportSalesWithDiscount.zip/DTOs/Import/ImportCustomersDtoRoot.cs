﻿using System.Xml.Serialization;

namespace CarDealer.DTOs.Import
{
    [XmlRoot("Customers")]
    public class ImportCustomersDtoRoot
    {
        [XmlElement("Customer")]
        public List<ImportCustomerDto> Customers { get; set; }
    }

}
