﻿using System.Xml.Serialization;

namespace CarDealer.DTOs.Export
{
    [XmlRoot("customers")]
    public class ExportCustomersTotalSalesRootDto
    {
        [XmlElement("customer")]
        public ExportCustomerTotalSalesDto[] Customers { get; set; }
    }

}
