﻿using System.Xml.Serialization;

namespace CarDealer.DTOs.Export
{
    [XmlRoot("sales")]
    public class ExportSalesWithDiscountRootDto
    {
        [XmlElement("sale")]
        public ExportSaleWithDiscountDto[] Sales { get; set; }
    }

}
