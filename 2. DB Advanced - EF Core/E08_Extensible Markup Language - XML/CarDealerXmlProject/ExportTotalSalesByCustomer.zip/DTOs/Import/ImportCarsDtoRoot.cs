﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using static CarDealer.DTOs.Import.ImportCarsDtoRoot;

namespace CarDealer.DTOs.Import
{    
        [XmlRoot("Cars")]
        public class ImportCarsDtoRoot
        {
            [XmlElement("Car")]
            public List<ImportCarDto> Cars { get; set; }
        }
    }

