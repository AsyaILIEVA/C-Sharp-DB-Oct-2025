﻿using CarDealer.Data;
using CarDealer.DTOs.Export;
using CarDealer.DTOs.Import;
using CarDealer.Models;
using CarDealer.Utilities;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Text;
using System.Xml.Serialization;

namespace CarDealer
{
    public class StartUp
    {
        public static void Main()
        {
            using CarDealerContext dbContext = new CarDealerContext();
            //dbContext.Database.EnsureDeleted();
            //dbContext.Database.EnsureCreated();


            //string xmlFileText = ReadXmlDatasetFileContents("sales.xml");
            //string result = ImportSales(dbContext, xmlFileText);

            string xmlOutput = GetTotalSalesByCustomer(dbContext);
            File.WriteAllText(@"../../../Results/customers-total-sales.xml", xmlOutput);


            //string result = GetCarsWithDistance(dbContext);
            //WriteSerializationResult("cars.xml", result);
            //Console.WriteLine(result); 

        }
        public static string ImportSuppliers(CarDealerContext context, string inputXml)
        {
            XmlSerializer serializer = new XmlSerializer(
                typeof(ImportSupplierDto[]),
                new XmlRootAttribute("Suppliers"));

            var supplierDtos = (ImportSupplierDto[])serializer.Deserialize(new StringReader(inputXml));

            var suppliers = new List<Supplier>();

            foreach (var dto in supplierDtos)
            {
                
                if (string.IsNullOrWhiteSpace(dto.Name))
                    continue;

                suppliers.Add(new Supplier
                {
                    Name = dto.Name,
                    IsImporter = dto.IsImporter
                });
            }

            context.Suppliers.AddRange(suppliers);
            context.SaveChanges();

            return $"Successfully imported {suppliers.Count}";
        }


        public static string ImportParts(CarDealerContext context, string inputXml)
        {
            XmlSerializer serializer = new XmlSerializer(
                typeof(ImportPartDto[]),
                new XmlRootAttribute("Parts"));

            var partDtos = (ImportPartDto[])serializer.Deserialize(new StringReader(inputXml));

            var supplierIds = context.Suppliers.Select(s => s.Id).ToHashSet();

            var parts = partDtos
                .Where(dto => supplierIds.Contains(dto.SupplierId))
                .Select(dto => new Part
                {
                    Name = dto.Name,
                    Price = dto.Price,
                    Quantity = dto.Quantity,
                    SupplierId = dto.SupplierId
                })
                .ToArray();

            context.Parts.AddRange(parts);
            context.SaveChanges();

            return $"Successfully imported {parts.Length}";
        }

        //cars
        public static string ImportCars(CarDealerContext context, string inputXml)
        {
            XmlSerializer serializer = new XmlSerializer(
                typeof(ImportCarDto[]),
                new XmlRootAttribute("Cars"));

            var carDtos = (ImportCarDto[])serializer.Deserialize(new StringReader(inputXml));

            var partIds = context.Parts.Select(p => p.Id).ToHashSet();

            List<Car> cars = new List<Car>();

            foreach (var dto in carDtos)
            {
                var car = new Car
                {
                    Make = dto.Make,
                    Model = dto.Model,
                    TraveledDistance = dto.TraveledDistance,
                };

                var validParts = dto.Parts
                    .Select(p => p.Id)
                    .Where(id => partIds.Contains(id))
                    .Distinct();

                foreach (var pid in validParts)
                {
                    car.PartsCars.Add(new PartCar
                    {
                        PartId = pid
                    });
                }

                cars.Add(car);
            }

            context.Cars.AddRange(cars);
            context.SaveChanges();

            return $"Successfully imported {cars.Count}";
        }

        public static string ImportCustomers(CarDealerContext context, string inputXml)
        {
            XmlRootAttribute root = new XmlRootAttribute("Customers");
            XmlSerializer serializer = new XmlSerializer(typeof(ImportCustomerDto[]), root);

            ImportCustomerDto[] customerDtos;

            using (StringReader reader = new StringReader(inputXml))
            {
                customerDtos = (ImportCustomerDto[])serializer.Deserialize(reader);
            }

            List<Customer> customers = new List<Customer>();

            foreach (var customerDto in customerDtos)
            {
                if (!IsValid(customerDto))
                {
                    continue;
                }

                bool isBirthDateValid = DateTime
                    .TryParseExact(customerDto.BirthDate, "yyyy-MM-dd'T'HH:mm:ss",
                        CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime birthDate);
                bool isYoungDriverValid = bool
                    .TryParse(customerDto.IsYoungDriver, out bool isYoungDriver);
                if ((!isBirthDateValid) || (!isYoungDriverValid))
                {
                    continue;
                }

                Customer cust = new Customer
                {
                    Name = customerDto.Name,
                    BirthDate = DateTime.Parse(customerDto.BirthDate),
                    IsYoungDriver = isYoungDriverValid
                };

                customers.Add(cust);
            }

            context.Customers.AddRange(customers);
            context.SaveChanges();

            return $"Successfully imported {customers.Count}";
        }

        public static string ImportSales(CarDealerContext context, string inputXml)
        {
            // Deserialize XML
            XmlSerializer serializer = new XmlSerializer(typeof(ImportSaleDto[]), new XmlRootAttribute("Sales"));
            ImportSaleDto[] saleDtos;

            using (StringReader reader = new StringReader(inputXml))
            {
                saleDtos = (ImportSaleDto[])serializer.Deserialize(reader);
            }

            // Fetch existing IDs from DB for faster lookup
            var validCarIds = context.Cars.Select(c => c.Id).ToHashSet();
            var validCustomerIds = context.Customers.Select(c => c.Id).ToHashSet();

            List<Sale> sales = new List<Sale>();

            foreach (var dto in saleDtos)
            {
                // Skip if CarId or CustomerId doesn't exist in DB
                if (!validCarIds.Contains(dto.CarId) || !validCustomerIds.Contains(dto.CustomerId))
                    continue;

                // Skip invalid DTOs (optional, if you want to validate fields)
                if (!IsValid(dto))
                    continue;

                // Create Sale entity
                Sale sale = new Sale
                {
                    CarId = dto.CarId,
                    CustomerId = dto.CustomerId,
                    Discount = dto.Discount
                };

                sales.Add(sale);
            }

            context.Sales.AddRange(sales);
            context.SaveChanges();

            return $"Successfully imported {sales.Count}";
        }



        public static string GetSalesWithAppliedDiscount(CarDealerContext context)
        {
            var sales = context.Sales
                .Select(s => new
                {
                    Car = s.Car,
                    CustomerName = s.Customer.Name,
                    Discount = s.Discount,
                    Price = s.Car.PartsCars.Sum(pc => pc.Part.Price)
                })
                .ToList()
                .Select(s => new ExportSaleWithDiscountDto
                {
                    Car = new ExportSaleCarDto
                    {
                        Make = s.Car.Make,
                        Model = s.Car.Model,
                        TraveledDistance = s.Car.TraveledDistance
                    },
                    CustomerName = s.CustomerName,
                    Discount = ((int)s.Discount).ToString(),
                    Price = s.Price.ToString("F4"),
                    PriceWithDiscount = (s.Price * (1 - s.Discount / 100m)).ToString("F4")
                })
                .ToArray();

            var root = new ExportSalesWithDiscountRootDto { Sales = sales };

            return XmlSerializerWrapper.Serialize(root, "sales");
        }

        //public static string GetTotalSalesByCustomer(CarDealerContext context)
        //{
        //    var customers = context.Customers
        //        .Where(c => c.Sales.Any())
        //        .Select(c => new
        //        {
        //            c.Name,
        //            BoughtCars = c.Sales.Count(),
        //            TotalSpent = c.Sales.Sum(s =>
        //                s.Car.PartsCars.Sum(pc => pc.Part.Price) * (c.IsYoungDriver ? 0.95m : 1m))
        //        })
        //        .OrderByDescending(c => c.TotalSpent)
        //        .ToList()
        //        .Select(c => new ExportCustomerTotalSalesDto
        //        {
        //            FullName = c.Name,
        //            BoughtCars = c.BoughtCars,
        //            SpentMoney = c.TotalSpent.ToString("F2")
        //        })
        //        .ToArray();

        //    var root = new ExportCustomersTotalSalesRootDto { Customers = customers };

        //    return XmlSerializerWrapper.Serialize(root, "customers");
        //}

        public static string GetTotalSalesByCustomer(CarDealerContext context)
        {
            var tempDto = context.Customers
                .Where(c => c.Sales.Any())
                .Select(c => new
                {
                    FullName = c.Name,
                    BoughtCars = c.Sales.Count(),
                    SalesInfo = c.Sales.Select(s => new
                    {
                        Prices = c.IsYoungDriver
                            ? s.Car.PartsCars.Sum(p => Math.Round((double)p.Part.Price * 0.95, 2))
                            : s.Car.PartsCars.Sum(p => (double)p.Part.Price)
                    }).ToArray(),
                })
                .ToArray();

            TotalSalesByCustomerDto[] totalSalesDtos = tempDto
                .OrderByDescending(t => t.SalesInfo.Sum(s => s.Prices))
                .Select(t => new TotalSalesByCustomerDto()
                {
                    FullName = t.FullName,
                    BoughtCars = t.BoughtCars,
                    SpentMoney = t.SalesInfo.Sum(s => s.Prices).ToString("f2")
                })
                .ToArray();

            return Serializer<TotalSalesByCustomerDto[]>(totalSalesDtos, "customers");
        }

        private static string Serializer<T>(T dataTransferObjects, string xmlRootAttributeName)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(T), new XmlRootAttribute(xmlRootAttributeName));

            StringBuilder sb = new StringBuilder();
            using var write = new StringWriter(sb);

            XmlSerializerNamespaces xmlNamespaces = new XmlSerializerNamespaces();
            xmlNamespaces.Add(string.Empty, string.Empty);

            serializer.Serialize(write, dataTransferObjects, xmlNamespaces);

            return sb.ToString();
        }



        private static string ReadXmlDatasetFileContents(string fileName)
        {
            string xmlFileDirPath = Path
                .Combine(Directory.GetCurrentDirectory(), "../../../Datasets/");
            string xmlFileText = File
                .ReadAllText(xmlFileDirPath + fileName);

            return xmlFileText;
        }

        private static void WriteSerializationResult(string fileName, string text)
        {
            string xmlFileDirPath = Path
                .Combine(Directory.GetCurrentDirectory(), "../../../Results/");
            File
                .WriteAllText(xmlFileDirPath + fileName, text, Encoding.Unicode);
        }                     

        private static bool TryParseNullableInt(string? input, out int? val)
        {
            int? outValue = null;
            if (input != null)
            {
                bool isInputValid = int
                    .TryParse(input, out int ageVal);
                if (!isInputValid)
                {
                    val = outValue;
                    return false;
                }

                outValue = ageVal;
            }

            val = outValue;
            return true;
        }

        private static bool IsValid(object obj)
        {
            ValidationContext validationContext = new ValidationContext(obj);
            ICollection<ValidationResult> validationResults
                = new List<ValidationResult>();

            return Validator
                .TryValidateObject(obj, validationContext, validationResults);
        }
    }
}

