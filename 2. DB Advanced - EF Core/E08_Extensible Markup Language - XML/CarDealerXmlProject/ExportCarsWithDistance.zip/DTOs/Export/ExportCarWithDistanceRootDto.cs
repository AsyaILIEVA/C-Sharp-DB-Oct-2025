﻿using System.Xml.Serialization;

namespace CarDealer.DTOs.Export
{
    [XmlType("cars")]
    public class ExportCarWithDistanceRootDto
    {      
            [XmlElement("car")]
            public ExportCarsWithDistanceDto[] Cars { get; set; } = null!;       

    }
}
