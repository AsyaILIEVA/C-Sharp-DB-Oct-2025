﻿    namespace P01_StudentSystem.Data.Enumerations
    {
        public enum ResourceType
        {
            Video = 0,
            Presentation = 1,
            Document = 2,
            Other = 3
        }
    }


