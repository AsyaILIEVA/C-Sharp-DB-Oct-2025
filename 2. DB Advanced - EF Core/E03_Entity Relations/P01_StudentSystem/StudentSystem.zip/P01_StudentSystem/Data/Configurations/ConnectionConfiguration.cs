﻿namespace P01_StudentSystem.Data
{
    public static class ConnectionConfiguration
    {
        public const string CONNECTION_STRING =
             @"Server=.;Database=StudentSystem;Trusted_Connection=True;Encrypt=False;";
    }
}