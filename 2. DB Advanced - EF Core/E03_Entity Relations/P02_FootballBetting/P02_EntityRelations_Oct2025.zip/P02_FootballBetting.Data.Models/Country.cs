﻿namespace P02_FootballBetting.Data.Models
{
    using System.ComponentModel.DataAnnotations;

    using static Common.EntityValidation.Country;
    public class Country
    {
        [Key]
        public int CountryId { get; set; }

        [Required]
        [MaxLength(NameMaxLength)]//metadata, not validation
        public string Name { get; set; } = null!;

        public virtual ICollection<Town> Towns { get; set; }
            = new HashSet<Town>();

            }
}
