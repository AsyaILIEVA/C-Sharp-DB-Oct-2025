﻿namespace P02_FootballBetting.Data.Models
{
    public enum Prediction //enum - text literal who is mapped to number
    {
        Home = 0,
        Away = 1,
        Draw = 2,
    }
}
