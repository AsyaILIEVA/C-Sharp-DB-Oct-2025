﻿namespace P02_FootballBetting.Common
{
    public class ApplicationConstants
    {
        public const string ConnectionString = 
            @"Server=.;Database=FootballBetting_Oct2025;Trusted_Connection=True;Encrypt=False;";
    }
}
